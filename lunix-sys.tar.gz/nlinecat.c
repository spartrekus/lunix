
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h> 
#include <time.h>




///////////////////////////////////////////////////////////////////
void filecat(  char *filein )
{
  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];

  /////////////////////////////////////////////////
  {
    //fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

         if ( !feof(fp6) )
         {
 	      //fputs( fetchline , fp5 );
  	      //fputs( "\n", fp5 );
	      printf( "%s", fetchline );
	      printf( "\n" );
	 }
     }
     //fclose( fp5 );
     fclose( fp6 );
   }
}





int main( int argc, char *argv[])
{
    char cwd[PATH_MAX];
    
    ////////////////////////////////////////////////////////
    if ( argc == 2)
      {
	  filecat( argv[ 1 ] );
          return 0;
      }

    return 0;
}


