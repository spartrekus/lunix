
#include <stdio.h>
#include <string.h>
#include <stdlib.h>   // system
#include <unistd.h>   // chdir

#include <dirent.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

#ifdef _WIN32
#define OSSYSTEM 2
//windows
#define KEY_GALT_H 0x1a8
#define KEY_GALT_L 0x1ac
#else
// linux
#define OSSYSTEM 1
#define KEY_GALT_H 0xe8
#define KEY_GALT_L 0xec
#endif


  int x11_check_display() 
  {
        int x11_display_int = 0;
        char *displaycheck = getenv("DISPLAY");
        if ( displaycheck != NULL ) 
          x11_display_int = 1 ; 
         else
          x11_display_int = 0 ; 
        return x11_display_int;
  }



int main()
{
    char cwd[PATH_MAX];
    char cmdi[PATH_MAX];
    strncpy( cwd, "" , PATH_MAX );
    char pathbefore[PATH_MAX];
    strncpy( pathbefore , getcwd( cwd, PATH_MAX ) , PATH_MAX );

    ////////////////////////////////////////////////////////
    printf("%d\n", x11_check_display());
    return 0;
}


