
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
//        Something useful???
// Tuesday, March 9, 2010
//  Simple PING implementation in C
// http://www.blogger.com/rearrange?blogID=1859382632509146652
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
// Source: Reference: http://www.koders.com/c/fid30EA22902AFF5800481BBC6F65DADCDAF92D6E37.aspx
// Posted by Karthikeyan Periasamy at 12:34 PM  [IMG] [IMG]
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>

#include <errno.h>
#include <sys/signal.h>

#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>

#define DEFDATALEN      56
#define MAXIPLEN        60
#define MAXICMPLEN      76

int npinglog = 0;

static char *hostname = NULL;

static int in_cksum(unsigned short *buf, int sz)
{
   int nleft = sz;
   int sum = 0;
   unsigned short *w = buf;
   unsigned short ans = 0;

   while (nleft > 1) {
     sum += *w++;
     nleft -= 2;
   }

   if (nleft == 1) {
     *(unsigned char *) (&ans) = *(unsigned char *) w;
     sum += ans;
   }

   sum = (sum >> 16) + (sum & 0xFFFF);
   sum += (sum >> 16);
   ans = ~sum;
   return (ans);
 }

 static void noresp(int ign)
 {
   printf("No response from %s\n", hostname);
   exit(0);
 }

 static void nping(const char *host)
 {
   struct hostent *h;
   struct sockaddr_in pingaddr;
   struct icmp *pkt;
   int pingsock, c;
   char packet[DEFDATALEN + MAXIPLEN + MAXICMPLEN];

   if ((pingsock = socket(AF_INET, SOCK_RAW, 1)) < 0) {       /* 1 == ICMP */
     perror("ping: creating a raw socket");
     exit(1);
   }

   /* drop root privs if running setuid */
   setuid(getuid());

   memset(&pingaddr, 0, sizeof(struct sockaddr_in));

   pingaddr.sin_family = AF_INET;
   if (!(h = gethostbyname(host))) {
     fprintf(stderr, "ping: unknown host %s\n", host);
     exit(1);
   }
   memcpy(&pingaddr.sin_addr, h->h_addr, sizeof(pingaddr.sin_addr));
   hostname = h->h_name;

   pkt = (struct icmp *) packet;
   memset(pkt, 0, sizeof(packet));
   pkt->icmp_type = ICMP_ECHO;
   pkt->icmp_cksum = in_cksum((unsigned short *) pkt, sizeof(packet));

   c = sendto(pingsock, packet, sizeof(packet), 0,
              (struct sockaddr *) &pingaddr, sizeof(struct sockaddr_in));

   if (c < 0 || c != sizeof(packet)) {
     if (c < 0)
       perror("ping: sendto");
     fprintf(stderr, "ping: write incomplete\n");
     exit(1);
   }

   signal(SIGALRM, noresp);
   alarm(2);                                     /* give the host 5000ms to respond */
   /* listen for replies */
   while (1) {
     struct sockaddr_in from;
     size_t fromlen = sizeof(from);

     if ((c = recvfrom(pingsock, packet, sizeof(packet), 0,
                       (struct sockaddr *) &from, &fromlen)) < 0) {
       if (errno == EINTR)
         continue;
       perror("ping: recvfrom");
       continue;
     }
     if (c >= 76) {                   /* ip + icmp */
       struct iphdr *iphdr = (struct iphdr *) packet;

       pkt = (struct icmp *) (packet + (iphdr->ihl << 2));      /* skip ip hdr */
       if (pkt->icmp_type == ICMP_ECHOREPLY)
         break;
     }
   }
   printf("%s is active!\n", hostname);

   if ( npinglog == 1 )
   {
       chdir( getenv( "HOME" ) );
       FILE *fp;
       char charo[250];
       fp = fopen( ".nping.log", "ab+" );
        snprintf( charo, 250 , "%s is active!\n", hostname );
        fputs( charo, fp );
       fclose( fp ); 
   }
   return;
 }




int main( int argc, char *argv[])
{

    printf( "NPING\n" );

    if ( argc == 3)
    if ( strcmp( argv[1] , "--log" ) ==  0 ) 
    if ( strcmp( argv[2] , "" ) !=  0 ) 
    {
        npinglog = 1;
	printf( "NPING WITH LOG\n" );
        nping ( argv[ 2 ] );
	return 0;
    }

    if ( argc == 2)
    if ( strcmp( argv[1] , "" ) !=  0 ) 
    {
        nping ( argv[ 1 ] );
	return 0;
    }

    if ( argc != 2) {
		printf("usage: nping x.x.x.x\n");
		//exit(4);
		return 0;
    }



   return 0;
}

