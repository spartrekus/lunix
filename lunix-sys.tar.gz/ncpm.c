   
#include <stdio.h>
#include <string.h> 
#include <stdlib.h> 
#include <dirent.h> 
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  
#include <time.h>
#include <ctype.h>   //toupper


int main()
{
     int i = 0;
     //for ( i = 1 ; i <= 50 ; i++) printf( "\n" );

     printf( "\n" );
     printf("****************************\n");
     printf("** 2017, NCPM-INTERPRETER **\n" );
     printf("****************************\n");
     printf( "\n" );

     char rootdisk_path[PATH_MAX];
     strncpy( rootdisk_path, "/usr/local/ncpm" , PATH_MAX );

     char cwd[PATH_MAX];
     int ncmp_gameover = 0 ;
     int founditem = 0; 
     char str[PATH_MAX];
     while ( ncmp_gameover == 0 )
     {
            ncmp_gameover = 1 ;
             fflush(stdin);

	     founditem = 0;
	     printf("A:> ");
             scanf("%[^\t\n]s",str);

	     i = strlen(str); 
	     //printf("Text:%s, Length:%d\n",str,i);

	     if ( strcmp( str, "hello" ) == 0 )
	     {
	        printf( "Hello!\n" );
		founditem = 1;
	     }
	     else if ( strcmp( str, "pwd" ) == 0 )
	     {
	        printf( "%s\n", getcwd( cwd, PATH_MAX ));
		founditem = 1;
	     }
	     else if ( strcmp( str, "path" ) == 0 )
	     {
	        printf( "System: %s\n", rootdisk_path );
		founditem = 1;
	     }
	     else if ( strcmp( str, "cd .." ) == 0 )
	     {
	        chdir( ".." );
	        printf( "PWD: %s\n", getcwd( cwd, PATH_MAX) );
		founditem = 1;
	     }

             printf( "\n" );
     }

     return 0;
}











/*
           #include <stdio.h>

           int main(void)
           {
             int number, p = 0, n = 0;

             while (1) {
               printf("-> ");
               if (scanf("%d", &number) == 0) {
                   fflush(stdin);
                   printf("Err...\n");
   up vote         continue;
   9 down      }
    vote       fflush(stdin);
               if (number > 0) p++;
               else if (number < 0) n++;
               else break; 
             }

             printf("Read %d positive and %d negative numbers\n", p, n);
             return 0;
           }

*/








