#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <string.h>
///////////////////////////////////
#include <ctype.h>  // fexist
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
///////////////////////////////////
#include <unistd.h>  //define getcwd
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h> //
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  //define getcwd
// time 
#include <time.h>

#include "../lib/libcore.c"

char *fbasenamestatic(char *name)
{
  //char *name;
  char *base = name;
  while (*name)
    {
      if (*name++ == '/')
	{
	  base = name;
	}
    }
  return (base);
}


int main(int argc, char *argv[])
{
    char *buffer = NULL;
    int read;
    unsigned int len;

    read = getline(&buffer, &len, stdin);
    if (-1 != read)
      puts( strrlf( fbasenamestatic(  buffer  )) );

    free(buffer);
    return 0;
}
