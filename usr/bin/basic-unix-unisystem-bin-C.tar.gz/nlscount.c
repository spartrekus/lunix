
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <unistd.h>  //define getcwd
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>

double programme_output_files = 0;
double programme_output_dir = 0;



void listdir(const char *name, int indent)
{
    DIR *dir;
    struct dirent *entry;

    if (!(dir = opendir(name)))
        return;

    while ((entry = readdir(dir)) != NULL) 
    {
        if (entry->d_type == DT_DIR) 
	{
            char path[1024];

            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
                continue;

            snprintf( path, sizeof(path), "%s/%s", name, entry->d_name);

            char newdir[PATH_MAX];
            strncpy( newdir, name , PATH_MAX );
            strncat( newdir ,  "/"  , PATH_MAX - strlen( newdir ) -1 );
            strncat( newdir , entry->d_name , PATH_MAX - strlen( newdir ) -1 );

            programme_output_dir++;
            listdir( newdir , indent + 2);
        } 
	else 
	{
//             if (( programme_show_item == 1 ) 
// 	       || ( programme_show_item == 3 ) )
//                printf( "%s/%s\n", name , entry->d_name);
// 	    else  if ( programme_show_item == 4 )
//                printf("%s\n" , entry->d_name);
//                //printf("%*s- %s\n", indent, "", entry->d_name);
                 programme_output_files++;
        }
    }
    closedir(dir);
}



int main( int argc, char *argv[])
{ 
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////

    if ( argc >= 2)
      if ( strcmp( argv[1] , "" ) !=  0 )
      {
	 chdir( argv[ 1 ] );
      }

   char cwd[PATH_MAX];
   printf( "Path: %s\n",    getcwd( cwd, PATH_MAX ) );  

   listdir( ".", 0);

   printf( "Dir count: %f\n", programme_output_dir );
   printf( "File count: %f\n",  programme_output_files );
   return 0;
}



