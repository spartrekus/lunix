
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define PATH_MAX 250

int main( int argc, char *argv[])
{
    printf("Hello Pauli \n");
    char cmdi[PATH_MAX];
    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( strcmp( argv[1] , "" ) !=  0 ) 
      {
         //getchar();
         strncpy( cmdi, "", PATH_MAX );
         strncat( cmdi , " apt-get install -y " , PATH_MAX - strlen( cmdi ) -1 );
         strncat( cmdi , argv[1] , PATH_MAX - strlen( cmdi ) -1 );
         strncat( cmdi , "  " , PATH_MAX - strlen( cmdi ) -1 );
         system( cmdi );
         return 0;
      }

     return 0;
}


