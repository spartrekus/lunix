
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{

    char c;
    printf(" <Please Press Enter> \n");
    getchar();

    /*
    scanf(" %c",&c); 
    printf( "<Press Return to Continue>\n" ); 
    c = toupper(c);
    if    ( c == 'Y' ) 
       printf( "Yes\n");
    else if ( c == '1' ) 
       printf( "Yes\n");
    else  
    {
      printf( "No\n");
      return 0; 
    }
    */

    return 0;
}



