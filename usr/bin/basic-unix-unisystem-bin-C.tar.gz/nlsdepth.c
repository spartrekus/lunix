


//////////////
// nlsdepth
//////////////

  /*
   * File types
    #define DT_UNKNOWN       0
    #define DT_FIFO          1
    #define DT_CHR           2
    #define DT_DIR           4
    #define DT_BLK           6
    #define DT_REG           8
    #define DT_LNK          10
    #define DT_SOCK         12
    #define DT_WHT          14 
  */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <dirent.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

///////////////////////////////////
#include <ctype.h>  // fexist
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
///////////////////////////////////
#include <unistd.h>  //define getcwd


#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

///global
int programme_debug = 0;
double programme_linecount = 0;


static int compare_fun( const void *p, const void *q)
{
  const char *l = p ; 
  const char *r = q ; 
  int cmp; 
  cmp = strcmp( l, r );
  return cmp; 
}




int fexiststatic(char *a_option){
  // this work too on MS Windows!
  char dir1[PATH_MAX]; 
  char *dir2;
  DIR *dip;
  strncpy( dir1 , "",  PATH_MAX  );
  strncpy( dir1 , a_option,  PATH_MAX  );

  struct stat st_buf; 
  int status; 
  int fileordir = 0 ; 

  status = stat ( dir1 , &st_buf);
  if (status != 0) {
    fileordir = 0;
  }

  // this is compatible to check if a file exists
  FILE *fp2check = fopen( dir1  ,"r");
  if( fp2check ) {
  // exists
  fileordir = 1; 
  fclose(fp2check);
  } 

  if (S_ISDIR (st_buf.st_mode)) {
    fileordir = 2; 
  }
return fileordir;
/////////////////////////////
}


  static void loaddir( char *mysearchdir )
  {
    //printf( "Enter: %s \n" , mysearchdir );
    char newdir[PATH_MAX];
    //chdir( mysearchdir );

    unsigned filemax = 0;
    unsigned n=0;
    DIR *dirp;
    struct dirent *dp;
    //char idata[2240][250];
    int myfiletype;
    n = 0 ; 
    filemax = 0; 
    double ncount = 0;

    if ( programme_debug == 1 ) printf( "[%s]\n", mysearchdir);

    dirp = opendir( mysearchdir );
    //while  ((dp = readdir( dirp )) != NULL  &&  n < sizeof idata / sizeof idata[ 0 ]) 
    while  ((dp = readdir( dirp )) != NULL )  
	   {

            //n++;

            if ( strcmp( dp->d_name , "." ) != 0 )
            if ( strcmp( dp->d_name , ".." ) != 0 )
            if ( dp->d_name[0] !=  '.' )
            {
              // strncpy( idata[ n++ ] , dp->d_name , 250 );
              if ( dp->d_type == DT_DIR) 
	      //if ( fexiststatic( dp->d_name ) == 2 )
	      {
                 strncpy( newdir, mysearchdir , PATH_MAX );
                 strncat( newdir ,  "/"  , PATH_MAX - strlen( newdir ) -1 );
                 strncat( newdir ,  dp->d_name , PATH_MAX - strlen( newdir ) -1 );
	         //loaddir( dp->d_name );
		 //if ( programme_debug == 1 )
                    //printf( "[%s/%s](%d)\n", newdir,  dp->d_name , dp->d_type );
                    //printf( "[%s/%s](%d)\n", newdir,  dp->d_name , dp->d_type );
		  //  else
                    //printf( "[%s/%s]\n", newdir,  dp->d_name );
	         loaddir( newdir );
	      }
	      else
	      {
                 //printf( "%s/%s (%d)\n", mysearchdir,  dp->d_name , fexiststatic( dp->d_name ) );
		 if ( programme_debug == 0 )
                    printf( "%s/%s\n", mysearchdir,  dp->d_name );
		 else
                    printf( "%s/%s (%d) (%f/%f)\n", mysearchdir,  dp->d_name , dp->d_type , ncount++ , programme_linecount++ );
              }
            }
    }
    filemax = n-1 ; 
    closedir( dirp );
    //    printf( "%s %d\n", idata[ n ] , fexiststatic( idata[ n ] )  );
    // if ( n > 1 )
    //  qsort( idata, n , sizeof idata[0], compare_fun );
    //for( n = 0 ; n <= filemax ; n++)
 }




int main( int argc, char *argv[])
{ 
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    if ( argc == 3 )
      if ( strcmp( argv[1], "--debug" ) ==  0 ) 
      if ( fexiststatic( argv[2] ) ==  2 ) 
      {
	 chdir( argv[ 2 ] );
         programme_debug = 1;
      }


    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( fexiststatic( argv[1] ) ==  2 ) 
      {
	 chdir( argv[ 1 ] );
      }


   char toxi[PATH_MAX];
   loaddir( getcwd( toxi, PATH_MAX ) );
   return 0;
}



