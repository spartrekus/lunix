

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define KA1  "\x1B[32m"
#define KA2  "\x1B[33m"
#define KA3  "\x1B[34m"
#define KA4  "\x1B[35m"
#define KA5  "\x1B[36m"
#define KA6  "\x1B[37m"
#define KA7  "\x1B[38m"
#define KNRM  "\x1B[0m"



#include <stdio.h>

main(argc, argv)
int argc;
char *argv[];
{
	register int i, nflg;
	int j ; 

	nflg = 0;
	if(argc > 1 && argv[1][0] == '-' && argv[1][1] == 'n') {
		nflg++;
		argc--;
		argv++;
	}
	for(i=1; i<argc; i++) {

	        //printf("%s%s\n", KCYN, entry->d_name );
	        printf("%s", KA1 );
		fputs(argv[i], stdout);
	        printf("%s", KNRM );

	        printf("%s", KA2 );
		fputs(argv[i], stdout);
	        printf("%s", KNRM );

	        printf("%s", KA3 );
		fputs(argv[i], stdout);
	        printf("%s", KNRM );

	        printf("%s", KA4 );
		fputs(argv[i], stdout);
	        printf("%s", KNRM );

	        printf("%s", KA5 );
		fputs(argv[i], stdout);
	        printf("%s", KNRM );

	        printf("%s", KA6 );
		fputs(argv[i], stdout);
	        printf("%s", KNRM );

	        printf("%s", KA7 );
		fputs(argv[i], stdout);
	        printf("%s", KNRM );

		if (i < argc-1)
			putchar(' ');
	}
	if(nflg == 0)
		putchar('\n');
	exit(0);
}



