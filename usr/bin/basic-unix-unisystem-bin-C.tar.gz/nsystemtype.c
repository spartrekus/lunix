
#include <stdio.h>
#include <string.h>
#include <stdlib.h>   // system
#include <unistd.h>   // chdir

#include <dirent.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

#ifdef _WIN32
#define OSSYSTEM 2
//windows
#define KEY_GALT_H 0x1a8
#define KEY_GALT_L 0x1ac
#else
// linux
#define OSSYSTEM 1
#define KEY_GALT_H 0xe8
#define KEY_GALT_L 0xec
#endif


int main()
{
    char cwd[PATH_MAX];
    char cmdi[PATH_MAX];
    strncpy( cwd, "" , PATH_MAX );
    char pathbefore[PATH_MAX];
    strncpy( pathbefore , getcwd( cwd, PATH_MAX ) , PATH_MAX );

    ////////////////////////////////////////////////////////
    if ( OSSYSTEM == 1 )
      printf("- UNIX/BSD CONSOLE -\n");
    else if ( OSSYSTEM == 2 )
      printf("- WINDOWS CONSOLE -\n");
    return 0;
}


