

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h> //
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  
#include <time.h>

#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  


///////////////////////////////
///////////////////////////////
///////////////////////////////
char *strtimestampstatic()
{
      long t;
      struct tm *ltime;
      time(&t);
      ltime=localtime(&t);
      char charo[50];  int fooi ; 
      fooi = snprintf( charo, 50 , "%04d%02d%02d%02d%02d%02d",
	1900 + ltime->tm_year, ltime->tm_mon +1 , ltime->tm_mday, 
	ltime->tm_hour, ltime->tm_min, ltime->tm_sec 
	);
    size_t siz = sizeof charo ; 
    char *r = malloc( sizeof charo );
    return r ? memcpy(r, charo, siz ) : NULL;
}










char *strrlf(char *str)
{ 
      char ptr[strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        if (str[i] != '\n' && str[i] != '\n') 
        ptr[j++]=str[i];
      } 
      ptr[j]='\0';
      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}

void drawit()
{
    printf(  "%s", strtimestampstatic() );
    printf(  " - Terminal Daemon (Wait) - \n" );
}


/// nwatch
int main( int argc, char *argv[])
{
    char cwd[PATH_MAX];
    printf("================= \n");
    printf("|||- NWATCH -||| \n");
    printf("================= \n");
    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( strcmp( argv[1], "" ) != 0 )
      {
         char linereadtmp[PATH_MAX];
         char lineread[PATH_MAX];
         FILE *fp1;

         int star_gameover = 0;
         while( star_gameover == 0 )
         {

         fp1 = popen( argv[ 1 ] , "r");
         while( !feof(fp1) ) 
         {
             fgets(linereadtmp, PATH_MAX, fp1); 
             strncpy( lineread, strrlf(linereadtmp) , PATH_MAX );
             if ( !feof(fp1) )  
	        printf( "%s\n" , lineread );
         }
         pclose( fp1 );

         usleep( 10 * 3 * 1e5 );
	 printf( "-----------------\n");

	 }
         return 0;
      }


     printf("Starfield: Bye! \n" );
     return 0;
}




