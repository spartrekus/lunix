

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h> //
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  
#include <time.h>


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  //define getcwd
#include <time.h>

///////////////////////////////
///////////////////////////////
///////////////////////////////
char *strtimestampstatic()
{
      long t;
      struct tm *ltime;
      time(&t);
      ltime=localtime(&t);
      char charo[50];  int fooi ; 
      fooi = snprintf( charo, 50 , "%04d%02d%02d%02d%02d%02d",
	1900 + ltime->tm_year, ltime->tm_mon +1 , ltime->tm_mday, 
	ltime->tm_hour, ltime->tm_min, ltime->tm_sec 
	);
    size_t siz = sizeof charo ; 
    char *r = malloc( sizeof charo );
    return r ? memcpy(r, charo, siz ) : NULL;
}







void drawit()
{
    printf(  "%s", strtimestampstatic() );
    printf(  " - NLOCKINFO - \n " );
}



////////////////////////////////////////

void lspid( char *processnametmp )
{
   printf( " LSPID:\n" );

   FILE *fp;  
   int i ; 
   char charo[PATH_MAX];
   char cmdi[PATH_MAX];
   char processname[PATH_MAX];
   strncpy( processname, processnametmp , PATH_MAX );
   //strncpy( processname, "bash" , PATH_MAX );

   //printf( "Search %s\n", processname );

   int psfound = 0;
   const char* directory = "/proc";
   size_t      taskNameSize = 1024;
   char*       taskName = calloc(1, taskNameSize);
   DIR* dir = opendir(directory);
   if (dir)
   {
      struct dirent* de = 0;

      while ((de = readdir(dir)) != 0)
      {
         if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0)
            continue;

         int pid = -1;
         int res = sscanf(de->d_name, "%d", &pid);

         if (res == 1)
         {
            // we have a valid pid
            // open the cmdline file to determine what's the name of the process running
            char cmdline_file[1024] = {0};
            sprintf(cmdline_file, "%s/%d/cmdline", directory, pid);

            FILE* cmdline = fopen(cmdline_file, "r");

            if (getline(&taskName, &taskNameSize, cmdline) > 0)
            {
               // is it the process we care about?
               if (strstr(taskName, processname ) != 0)
               {
                  //fprintf(stdout, "A %s process, with PID %d, has been detected.\n", argv[1], pid);
                  i = snprintf( charo, 100 , "  A %s process, with PID %d, has been detected.", taskName , pid);
		  printf( "%s \n", charo );
               }
            }

            fclose(cmdline);
         }
      }

      closedir(dir);
     }
}





int main( int argc, char *argv[])
{
    int i ; 
    char pidname[PATH_MAX];
    strncpy( pidname, "dd" , PATH_MAX );

    for( i = 1 ; i <= 50 ; i++) printf(  "\n" );

    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( strcmp( argv[1] , "" ) !=  0 ) 
      {
         strncpy( pidname, argv[ 1 ], PATH_MAX );
      }
        
       int star_gameover = 0;
       while( star_gameover == 0 )
       {
             drawit();
	     lspid( pidname );
             usleep( 10 * 5 * 1e5 );
       }
       return 0;

  return 0;
}






