
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>

static char *read_stdin()
{
    char buffer[BUFSIZ];
    char *output;
    int extra;
    int length = 0;
    int bulk = 1024;
    output = (char *) malloc(bulk);
    strcpy(output, "");
    while ((extra = fread(buffer, 1, BUFSIZ, stdin))) {
        while (length + extra > bulk - 1) {
            bulk += bulk >> 1;
            output = (char *) realloc(output, bulk);
        }
        strncat(output, buffer, extra);
        length += strlen(buffer);
    }
    return output;
}


int main(int argc, char *argv[])
{
    char *raw_html;
    if (argc != 1) {
        fprintf(stderr, "%s expects no arguments\n", argv[0]);
        return 1;
    }
    raw_html = read_stdin();
    printf( "%s", raw_html );
    free(raw_html);
    return 0;
}


