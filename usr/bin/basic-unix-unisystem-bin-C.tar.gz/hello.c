
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    printf("- TERMINAL4PI -\n");
    printf("Hello World \n");
    return 0;
}


