
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{

    char c;
    printf("Do you want to confirm (y/n)? ");
    scanf(" %c",&c); c = toupper(c);
    if    ( c == 'Y' ) 
       printf( "Yes\n");
    else if ( c == '1' ) 
       printf( "Yes\n");
    else  
    {
      printf( "No\n");
      return 0; 
    }

    return 0;
}



