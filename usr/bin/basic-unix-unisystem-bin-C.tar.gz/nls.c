
//////////////
//
// nlslist
// 
//////////////
// based on: https://stackoverflow.com/questions/8436841/how-to-recursively-list-directories-in-c-on-linux
// modded by me
// open source for Unix/BSD
//////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define KCYN  "\x1B[36m"
#define KNRM  "\x1B[0m"

#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>

int programme_debug    = 0;
int programme_show_item =  3;    //1: file,  2:dir, 3: both
int programme_show_color = 0; 



void listdir(const char *name, int indent)
{
    DIR *dir;
    struct dirent *entry;

    if (!(dir = opendir(name)))
        return;

    //if ( ( programme_show_item ==  2 ) || ( programme_show_item == 3 ) || ( programme_show_item == 4 ) )
       //printf( "[%s]\n", name );

    while ((entry = readdir(dir)) != NULL) 
    {
        if (entry->d_type == DT_DIR) 
	{
            char path[1024];

            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
                continue;

            snprintf( path, sizeof(path), "%s/%s", name, entry->d_name);

            if ( programme_debug == 1 )
               printf("%*s[%s]\n", indent, "", entry->d_name);

            char newdir[PATH_MAX];
            strncpy( newdir, name , PATH_MAX );
            strncat( newdir ,  "/"  , PATH_MAX - strlen( newdir ) -1 );
            strncat( newdir , entry->d_name , PATH_MAX - strlen( newdir ) -1 );

            if ( programme_debug == 1 )
	      printf( "Loading [%s]\n", newdir );

            //listdir( newdir , indent + 2);
             if ( ( programme_show_item ==  2 ) || ( programme_show_item == 3 ) || ( programme_show_item == 4 ) )
	     {
               //printf("[%s]\n" , entry->d_name);
	       if ( programme_show_color == 1 )
	       {
	         printf("%s%s\n", KCYN, entry->d_name );
	         printf("%s", KNRM );
	       }
	       else 
	       {
                 printf("%s\n" , entry->d_name);
	       }
	     }

        } 
	else 
	{
            if (( programme_show_item == 1 ) 
	       || ( programme_show_item == 3 ) )
               printf( "%s/%s\n", name , entry->d_name);
	    else  if ( programme_show_item == 4 )
               printf("%s\n" , entry->d_name);
               //printf("%*s- %s\n", indent, "", entry->d_name);
        }
    }
    closedir(dir);
}


//[[[
/*
int main( int argc, char *argv[])
{
    ////////////////////////////////////////////////////////
    if ( argc == 2)
    if ( strcmp( argv[1] , "" ) !=  0 ) 
    {
         chdir( argv[ 1 ] );
    }

    listdir( ".", 0);
    return 0;
} */
//]]]



int main( int argc, char *argv[])
{ 
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    if ( argc == 3 )
      if ( strcmp( argv[1], "--debug" ) ==  0 ) 
      {
         programme_debug = 1;
	 chdir( argv[ 2 ] );
      }

    if ( argc >= 2 )
      if ( strcmp( argv[1], "--nocolor" ) ==  0 ) 
      {
         programme_show_color = 0;
      }
    if ( argc >= 2 )
      if ( strcmp( argv[1], "--color" ) ==  0 ) 
      {
         programme_show_color = 1;
      }


    if ( argc >= 2 )
      if ( strcmp( argv[1], "--dir" ) ==  0 ) 
      {
         programme_show_item = 2;    //1: file,  2:dir, 3: both
      }
    if ( argc >= 2 )
      if ( strcmp( argv[1], "--file" ) ==  0 ) 
      {
         programme_show_item = 1;    //1: file,  2:dir, 3: both
      }
    if ( argc >= 2 )
      if ( strcmp( argv[1], "--all" ) ==  0 ) 
      {
         programme_show_item = 3;    //1: file,  2:dir, 3: both
      }
    if ( argc >= 2 )
      if ( strcmp( argv[1], "--base" ) ==  0 ) 
      {  // base for tiny file name + with dir 
         // mode 4 is special
         programme_show_item = 4;    //1: file,  2:dir, 3: both
      }

    ////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    if ( argc == 3 )
      if ( strcmp( argv[1], "--debug" ) !=  0 ) 
      {
	 chdir( argv[ 2 ] );
      }

    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( strcmp( argv[1] , "" ) !=  0 )
      {
	 chdir( argv[ 1 ] );
      }

   listdir( ".", 0);
   return 0;
}



